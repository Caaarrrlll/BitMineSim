#ifndef CRYPTO_H
#define CRYPTO_H

#include <iostream>
#include <cstdlib>
#include <sstream>
#include "sha1.hpp"

using namespace std;

class Crypto {
	public:
		string sha1hash(string s);
		string sha1hash(int v);
		string strtohex(string s, bool u = true);
		string random_string(int l);
};

#endif